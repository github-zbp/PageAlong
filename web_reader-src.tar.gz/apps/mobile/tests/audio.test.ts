jest.mock(
  "expo-audio",
  () => ({
    setAudioModeAsync: jest.fn()
  }),
  { virtual: true }
);

const { setAudioModeAsync } = require("expo-audio");

import { configureBackgroundAudio } from "@/lib/audio";

it("enables background audio mode with expo-audio", async () => {
  (setAudioModeAsync as jest.Mock).mockResolvedValueOnce(undefined);

  await configureBackgroundAudio();

  expect(setAudioModeAsync).toHaveBeenCalledWith(
    expect.objectContaining({
      playsInSilentMode: true,
      shouldPlayInBackground: true,
      interruptionMode: "duckOthers"
    })
  );
});
