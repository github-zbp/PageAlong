import type { PropsWithChildren, ReactNode } from "react";
import { View } from "react-native";
import { useTheme } from "@/providers/ThemeProvider";
import { TopAppBar } from "@/components/TopAppBar";

type Props = PropsWithChildren<{
  title: string;
  rightAction?: ReactNode;
  onRightAction?: () => void;
}>;

export function AppFrame({ title, rightAction, onRightAction, children }: Props) {
  const { tokens } = useTheme();

  return (
    <View style={{ flex: 1, backgroundColor: tokens.background }}>
      <TopAppBar title={title} rightAction={rightAction} onRightAction={onRightAction} />
      <View style={{ flex: 1 }}>{children}</View>
    </View>
  );
}
