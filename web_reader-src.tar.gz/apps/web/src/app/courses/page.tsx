import { redirect } from "next/navigation";

export default function CoursesPage() {
  redirect("/zh/library");
}
