import { Pressable, Text, View } from "react-native";
import { AppFrame } from "@/components/AppFrame";
import { Screen } from "@/components/Screen";
import { useSession } from "@/providers/SessionProvider";
import { useTheme } from "@/providers/ThemeProvider";

export default function MeScreen() {
  const { tokens, mode, toggleMode } = useTheme();
  const { state } = useSession();

  return (
    <AppFrame title="我的">
      <Screen>
        <View style={{ gap: 12 }}>
          <View
            style={{
              borderWidth: 1,
              borderColor: tokens.border,
              borderRadius: 12,
              padding: 16,
              backgroundColor: tokens.surface
            }}
          >
            <Text style={{ color: tokens.text, fontSize: 16, fontWeight: "600" }}>账号信息</Text>
            <Text style={{ color: tokens.mutedText, marginTop: 8 }}>
              {state.status === "signed_in" ? state.user.email : "登录入口会在下一阶段接入。"}
            </Text>
          </View>

          <Pressable
            onPress={toggleMode}
            style={{
              borderWidth: 1,
              borderColor: tokens.border,
              borderRadius: 12,
              padding: 16,
              backgroundColor: tokens.surface
            }}
          >
            <Text style={{ color: tokens.text, fontSize: 16, fontWeight: "600" }}>主题</Text>
            <Text style={{ color: tokens.mutedText, marginTop: 8 }}>
              当前是 {mode === "dark" ? "夜间" : "白天"} 模式，点击切换。
            </Text>
          </Pressable>
        </View>
      </Screen>
    </AppFrame>
  );
}
