import { clearAuthToken } from "@/lib/auth-storage";
import { clearSessionToken, getSessionToken } from "@/lib/session-store";

const DEFAULT_API_BASE_URL = "http://10.0.2.2:8070";
const API_BASE_URL = (process.env.EXPO_PUBLIC_API_BASE_URL ?? DEFAULT_API_BASE_URL).replace(/\/+$/, "");

export type AuthUser = {
  id: string;
  email: string;
  role: "user" | "admin";
  status: "active" | "disabled";
  email_verified_at: string | null;
  must_change_password_at_next_login: boolean;
  last_login_at: string | null;
  created_at: string;
};

type ErrorBody = {
  detail?: unknown;
};

function buildUrl(path: string): string {
  return `${API_BASE_URL}${path}`;
}

async function responseErrorMessage(response: Response, fallback: string): Promise<string> {
  try {
    const body = (await response.json()) as ErrorBody;
    if (typeof body.detail === "string" && body.detail.trim()) {
      return body.detail;
    }
  } catch {
    // Ignore parse failures and fall back to the generic message.
  }

  return fallback;
}

export async function apiFetch(path: string, init: RequestInit = {}, auth = true): Promise<Response> {
  const headers = new Headers(init.headers);

  if (auth) {
    const token = getSessionToken();
    if (token) {
      headers.set("Authorization", `Bearer ${token}`);
    }
  }

  const response = await fetch(buildUrl(path), {
    ...init,
    headers
  });

  if (auth && response.status === 401) {
    clearSessionToken();
    await clearAuthToken();
  }

  return response;
}

export async function apiJson<T>(
  path: string,
  init: RequestInit = {},
  fallback = "Request failed",
  auth = true
): Promise<T> {
  const response = await apiFetch(path, init, auth);
  if (!response.ok) {
    throw new Error(await responseErrorMessage(response, fallback));
  }
  return (await response.json()) as T;
}

export async function apiNoContent(
  path: string,
  init: RequestInit = {},
  fallback = "Request failed",
  auth = true
): Promise<void> {
  const response = await apiFetch(path, init, auth);
  if (!response.ok) {
    throw new Error(await responseErrorMessage(response, fallback));
  }
}

export async function getCurrentUser(): Promise<AuthUser> {
  return apiJson<AuthUser>("/auth/me", { cache: "no-store" }, "Failed to load account");
}
