import type { ExpoConfig } from "expo/config";

export default (): ExpoConfig => ({
  name: "PageAlong",
  slug: "pagealong",
  scheme: "pagealong",
  orientation: "portrait",
  platforms: ["android"],
  android: {
    package: "com.pagealong.app"
  },
  extra: {
    apiBaseUrl: process.env.EXPO_PUBLIC_API_BASE_URL ?? "http://10.0.2.2:8070"
  },
  plugins: ["expo-router", "expo-secure-store"]
});
