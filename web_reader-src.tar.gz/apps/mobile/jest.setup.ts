import "@testing-library/jest-native/extend-expect";

jest.mock("expo-secure-store", () => ({
  getItemAsync: jest.fn(),
  setItemAsync: jest.fn(),
  deleteItemAsync: jest.fn()
}));

jest.mock("@expo/vector-icons", () => {
  const React = require("react");
  return {
    Feather: (props: unknown) => React.createElement("Feather", props)
  };
});
