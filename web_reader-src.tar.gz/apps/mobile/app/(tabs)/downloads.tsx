import { Text, View } from "react-native";
import { AppFrame } from "@/components/AppFrame";
import { Screen } from "@/components/Screen";
import { useTheme } from "@/providers/ThemeProvider";

export default function DownloadsScreen() {
  const { tokens } = useTheme();

  return (
    <AppFrame title="下载资源">
      <Screen>
        <View
          style={{
            borderWidth: 1,
            borderColor: tokens.border,
            borderRadius: 12,
            padding: 16,
            backgroundColor: tokens.surface
          }}
        >
          <Text style={{ color: tokens.text, fontSize: 16, fontWeight: "600" }}>下载资源</Text>
          <Text style={{ color: tokens.mutedText, marginTop: 8 }}>导入与下载任务中心会在后续 spec 中补齐。</Text>
        </View>
      </Screen>
    </AppFrame>
  );
}
