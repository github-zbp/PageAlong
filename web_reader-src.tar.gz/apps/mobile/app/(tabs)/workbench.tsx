import { Text, View } from "react-native";
import { AppFrame } from "@/components/AppFrame";
import { Screen } from "@/components/Screen";
import { useSession } from "@/providers/SessionProvider";
import { useTheme } from "@/providers/ThemeProvider";

export default function WorkbenchScreen() {
  const { tokens } = useTheme();
  const { state } = useSession();

  return (
    <AppFrame title="工作台">
      <Screen>
        <View style={{ gap: 12 }}>
          <View
            style={{
              borderWidth: 1,
              borderColor: tokens.border,
              borderRadius: 12,
              padding: 16,
              backgroundColor: tokens.surface
            }}
          >
            <Text style={{ color: tokens.text, fontSize: 16, fontWeight: "600" }}>继续学习</Text>
            <Text style={{ color: tokens.mutedText, marginTop: 8 }}>
              {state.status === "signed_in" ? `当前账号：${state.user.email}` : "会话会在后续登录流程接入后恢复。"}
            </Text>
          </View>

          <View
            style={{
              borderWidth: 1,
              borderColor: tokens.border,
              borderRadius: 12,
              padding: 16,
              backgroundColor: tokens.surface
            }}
          >
            <Text style={{ color: tokens.text, fontSize: 16, fontWeight: "600" }}>最近阅读</Text>
            <Text style={{ color: tokens.mutedText, marginTop: 8 }}>这里会在后续 spec 中接入课程列表。</Text>
          </View>
        </View>
      </Screen>
    </AppFrame>
  );
}
