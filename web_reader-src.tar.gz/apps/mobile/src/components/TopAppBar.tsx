import type { ReactNode } from "react";
import { Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useTheme } from "@/providers/ThemeProvider";

type Props = {
  title: string;
  rightAction?: ReactNode;
  onRightAction?: () => void;
};

export function TopAppBar({ title, rightAction, onRightAction }: Props) {
  const { tokens } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={{
        borderBottomWidth: 1,
        borderBottomColor: tokens.border,
        backgroundColor: tokens.surface,
        paddingLeft: 16 + insets.left,
        paddingRight: 16 + insets.right,
        paddingTop: 12 + insets.top,
        paddingBottom: 12
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <Text style={{ color: tokens.text, fontSize: 18, fontWeight: "600" }}>{title}</Text>
        {onRightAction ? (
          <Pressable onPress={onRightAction} hitSlop={10} accessibilityRole="button">
            {rightAction ?? <Feather name="settings" size={20} color={tokens.mutedText} />}
          </Pressable>
        ) : (
          rightAction ?? <Feather name="settings" size={20} color={tokens.mutedText} />
        )}
      </View>
    </View>
  );
}
