import { NextResponse, type NextRequest } from "next/server";

function isMarketingPath(pathname: string): boolean {
  return (
    pathname === "/" ||
    pathname === "/guide" ||
    pathname === "/download" ||
    pathname === "/story" ||
    pathname === "/privacy" ||
    pathname === "/terms" ||
    pathname === "/blog" ||
    pathname.startsWith("/blog/")
  );
}

function englishMarketingPath(pathname: string): string {
  return pathname === "/" ? "/en" : `/en${pathname}`;
}

export function middleware(request: NextRequest) {
  const url = request.nextUrl;
  if (url.searchParams.get("lang") === "en" && isMarketingPath(url.pathname)) {
    const redirectUrl = url.clone();
    redirectUrl.pathname = englishMarketingPath(url.pathname);
    redirectUrl.searchParams.delete("lang");
    return NextResponse.redirect(redirectUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/", "/guide", "/download", "/story", "/privacy", "/terms", "/blog/:path*"]
};
