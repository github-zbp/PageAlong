import { Tabs } from "expo-router";
import { TabBar } from "@/components/TabBar";
import { TAB_ROUTES } from "@/lib/navigation";
import { useTheme } from "@/providers/ThemeProvider";

export default function TabsLayout() {
  const { tokens } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: tokens.accent,
        tabBarInactiveTintColor: tokens.mutedText,
        tabBarStyle: { borderTopColor: tokens.border, backgroundColor: tokens.surface }
      }}
      tabBar={(props) => <TabBar {...props} />}
    >
      {TAB_ROUTES.map((route) => (
        <Tabs.Screen
          key={route.name}
          name={route.name}
          options={{
            title: route.title
          }}
        />
      ))}
    </Tabs>
  );
}
