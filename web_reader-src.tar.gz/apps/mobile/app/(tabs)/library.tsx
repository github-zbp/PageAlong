import { Text, View } from "react-native";
import { AppFrame } from "@/components/AppFrame";
import { Screen } from "@/components/Screen";
import { useTheme } from "@/providers/ThemeProvider";

export default function LibraryScreen() {
  const { tokens } = useTheme();

  return (
    <AppFrame title="课程库">
      <Screen>
        <View
          style={{
            borderWidth: 1,
            borderColor: tokens.border,
            borderRadius: 12,
            padding: 16,
            backgroundColor: tokens.surface
          }}
        >
          <Text style={{ color: tokens.text, fontSize: 16, fontWeight: "600" }}>课程库</Text>
          <Text style={{ color: tokens.mutedText, marginTop: 8 }}>课程列表与筛选会在下一阶段接入。</Text>
        </View>
      </Screen>
    </AppFrame>
  );
}
