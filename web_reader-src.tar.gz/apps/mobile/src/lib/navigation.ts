import type { ComponentProps } from "react";
import { Feather } from "@expo/vector-icons";

export const TAB_ROUTES = [
  { name: "workbench", title: "工作台", icon: "home" as const },
  { name: "library", title: "课程库", icon: "book-open" as const },
  { name: "downloads", title: "下载资源", icon: "download" as const },
  { name: "me", title: "我的", icon: "user" as const }
] as const;

export type TabRoute = (typeof TAB_ROUTES)[number];
export type TabIconName = ComponentProps<typeof Feather>["name"];
