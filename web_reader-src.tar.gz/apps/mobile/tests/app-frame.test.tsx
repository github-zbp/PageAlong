jest.mock("@/providers/ThemeProvider", () => ({
  useTheme: () => ({
    mode: "light",
    tokens: {
      background: "#F7F4ED",
      surface: "#FFFDF8",
      elevatedSurface: "#FFFFFF",
      border: "#E5DED2",
      text: "#171717",
      mutedText: "#6B6760",
      accent: "#2F6F5E",
      highlight: "#D7B46A",
      danger: "#A33A2B"
    },
    setMode: jest.fn(),
    toggleMode: jest.fn()
  })
}));

jest.mock("react-native-safe-area-context", () => ({
  useSafeAreaInsets: () => ({
    top: 24,
    right: 0,
    bottom: 0,
    left: 0
  })
}));

import { render } from "@testing-library/react-native";
import { StyleSheet } from "react-native";
import { AppFrame } from "@/components/AppFrame";
import { TopAppBar } from "@/components/TopAppBar";
import { TAB_ROUTES } from "@/lib/navigation";

it("renders the top frame and all four tab labels", async () => {
  const screen = await render(
    <AppFrame title="工作台">
      <></>
    </AppFrame>
  );

  expect(screen.getByText("工作台")).toBeTruthy();
  expect(TAB_ROUTES).toHaveLength(4);
  expect(TAB_ROUTES.map((route) => route.title)).toEqual(["工作台", "课程库", "下载资源", "我的"]);
});

it("keeps the top app bar content below the system status bar", async () => {
  const screen = await render(<TopAppBar title="工作台" />);
  const topBar = screen.toJSON();

  expect(topBar).toBeTruthy();
  expect(StyleSheet.flatten(topBar?.props.style)).toEqual(
    expect.objectContaining({
      paddingTop: 36,
      paddingBottom: 12
    })
  );
});
