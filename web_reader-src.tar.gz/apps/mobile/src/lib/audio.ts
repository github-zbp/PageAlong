import { setAudioModeAsync } from "expo-audio";

export async function configureBackgroundAudio(): Promise<void> {
  await setAudioModeAsync({
    playsInSilentMode: true,
    shouldPlayInBackground: true,
    interruptionMode: "duckOthers"
  });
}
