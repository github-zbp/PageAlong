import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { SiteChrome } from "@/components/SiteChrome";
import { getPublicBlog } from "@/lib/api";
import {
  importTextHref,
  marketingFooterLinks,
  marketingFooterNote,
  marketingHref,
  marketingNavLinks
} from "@/lib/site";
import type { Locale } from "@/lib/i18n";

export const metadata: Metadata = {
  title: "博客 - 页相随 PageAlong"
};

function normalizeLocale(value: string | string[] | undefined): Locale {
  const rawValue = Array.isArray(value) ? value[0] : value;
  return rawValue === "en" ? "en" : "zh";
}

function formatDate(value: string | null, locale: Locale): string {
  if (!value) {
    return "";
  }
  return new Intl.DateTimeFormat(locale === "zh" ? "zh-CN" : "en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(value));
}

export default async function BlogDetailPage({
  params,
  searchParams
}: {
  params: { slug: string };
  searchParams?: { lang?: string | string[] };
}) {
  const locale = normalizeLocale(searchParams?.lang);
  const post = await getPublicBlog(params.slug, locale).catch(() => null);
  if (!post) {
    notFound();
  }

  return (
    <SiteChrome
      locale={locale}
      homeHref={marketingHref("/", locale)}
      brandPrimary={locale === "zh" ? "页相随" : "PageAlong"}
      brandSecondary={locale === "zh" ? "把读不完的内容，变成一路相随的课程" : "Turn long reads into courses that follow along."}
      navLinks={marketingNavLinks(locale)}
      activeNavHref={marketingHref("/blog", locale)}
      localeLinks={{
        zh: marketingHref(`/blog/${post.slug}`, "zh"),
        en: marketingHref(`/blog/${post.slug}`, "en")
      }}
      primaryCta={{ href: importTextHref(locale), label: locale === "zh" ? "免费使用" : "Use for free" }}
      footerLinks={marketingFooterLinks(locale)}
      footerNote={marketingFooterNote[locale]}
    >
      <article className="mx-auto max-w-3xl px-4 py-14 sm:py-16">
        <Link className="pa-focus text-sm text-[var(--pa-muted)] underline underline-offset-4" href={marketingHref("/blog", locale)}>
          {locale === "zh" ? "返回博客" : "Back to blog"}
        </Link>
        <h1 className="mt-5 text-3xl font-semibold tracking-normal text-[var(--pa-ink)]">{post.title}</h1>
        <p className="mt-3 text-sm text-[var(--pa-muted)]">{formatDate(post.published_at ?? post.created_at, locale)}</p>
        {post.summary ? <p className="mt-5 text-base leading-7 text-[var(--pa-muted)]">{post.summary}</p> : null}
        <div
          className="mt-8 max-w-none space-y-4 text-base leading-8 text-[var(--pa-ink)] [&_a]:underline [&_a]:underline-offset-4 [&_h2]:pt-4 [&_h2]:text-xl [&_h2]:font-semibold [&_h3]:pt-3 [&_h3]:text-lg [&_h3]:font-semibold [&_li]:ml-5 [&_li]:list-disc [&_p]:leading-8"
          dangerouslySetInnerHTML={{ __html: post.body_html }}
        />
      </article>
    </SiteChrome>
  );
}
